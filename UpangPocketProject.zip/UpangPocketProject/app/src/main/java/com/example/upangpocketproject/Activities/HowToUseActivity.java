package com.example.upangpocketproject.Activities;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.upangpocketproject.R;

public class HowToUseActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_how_to_use);
    }
}